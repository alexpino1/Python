def bisiesto(año):
    if año % 4 == 0:
        print("el año: ", año, " es bisiesto")

    else:
        print("el año: ", año, " NO es bisiesto")


bisiesto(2021)